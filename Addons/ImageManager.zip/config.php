<?php
return array(
	'page_size'=>array(
		'title'=>'每页显示数:',
		'type'=>'text',
		'value'=>'20'
	),
);